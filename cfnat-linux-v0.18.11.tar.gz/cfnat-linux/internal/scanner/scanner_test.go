package scanner

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net"
	"net/http"
	"net/netip"
	"os"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/cfnat-linux/cfnat-linux/internal/config"
)

func TestGenerateCandidatesInsidePrefix(t *testing.T) {
	prefix := netip.MustParsePrefix("192.0.2.0/24")
	items, err := generateCandidates([]netip.Prefix{prefix}, true, 100)
	if err != nil {
		t.Fatal(err)
	}
	if len(items) != 100 {
		t.Fatalf("got %d candidates", len(items))
	}
	seen := map[netip.Addr]bool{}
	for _, ip := range items {
		if !prefix.Contains(ip) {
			t.Fatalf("%s outside prefix", ip)
		}
		if seen[ip] {
			t.Fatalf("duplicate %s", ip)
		}
		seen[ip] = true
	}
}

func TestFilterBlacklistRemovesIPsAndCIDRs(t *testing.T) {
	candidates := []netip.Addr{
		netip.MustParseAddr("192.0.2.1"),
		netip.MustParseAddr("192.0.2.2"),
		netip.MustParseAddr("198.51.100.1"),
	}
	filtered := filterBlacklist(candidates, []string{"192.0.2.1", "198.51.100.0/24"})
	if len(filtered) != 1 || filtered[0] != netip.MustParseAddr("192.0.2.2") {
		t.Fatalf("filtered = %v", filtered)
	}
}

func TestTraceValue(t *testing.T) {
	if got := traceValue("ip=1.2.3.4\ncolo=HKG\n", "colo"); got != "HKG" {
		t.Fatalf("got %q", got)
	}
}

func TestReadPrefixesAcceptsBareIPCIDRAndComments(t *testing.T) {
	dir := t.TempDir()
	path := dir + "/ips.txt"
	content := "104.16.0.1\n104.17.0.0/24 # useful\ninvalid\n2001:db8::1\n"
	if err := os.WriteFile(path, []byte(content), 0600); err != nil {
		t.Fatal(err)
	}
	cfg := config.Defaults()
	cfg.IPSources = []string{path}
	cfg.SourceCacheDir = dir + "/cache"
	s := New(cfg, slog.New(slog.NewTextHandler(io.Discard, nil)))
	prefixes, err := s.readPrefixes(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	want := map[netip.Prefix]bool{
		netip.MustParsePrefix("104.16.0.1/32"): true,
		netip.MustParsePrefix("104.17.0.0/24"): true,
	}
	if len(prefixes) != len(want) {
		t.Fatalf("got %v", prefixes)
	}
	for _, prefix := range prefixes {
		if !want[prefix] {
			t.Fatalf("unexpected %s", prefix)
		}
	}
}

func TestProbeRejectsIPAboveLatencyLimit(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	server := &http.Server{Handler: http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})}
	defer server.Close()
	go server.Serve(listener)

	_, portText, _ := net.SplitHostPort(listener.Addr().String())
	port, _ := strconv.Atoi(portText)
	cfg := config.Defaults()
	cfg.TargetPort = port
	cfg.TLS = false
	cfg.CheckURL = "http://example.com/"
	cfg.MaxLatency = config.Duration(time.Nanosecond)
	cfg.DialTimeout = config.Duration(time.Second)
	s := New(cfg, slog.New(slog.NewTextHandler(io.Discard, nil)))
	_, err = s.Probe(context.Background(), netip.MustParseAddr("127.0.0.1"))
	if err == nil || !strings.Contains(err.Error(), "超过限制") {
		t.Fatalf("expected latency rejection, got %v", err)
	}
}

func TestProbeTCPMode(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	go func() {
		for {
			conn, err := listener.Accept()
			if err != nil {
				return
			}
			_ = conn.Close()
		}
	}()
	_, portText, _ := net.SplitHostPort(listener.Addr().String())
	port, _ := strconv.Atoi(portText)
	cfg := config.Defaults()
	cfg.ProbeMode = "tcp"
	cfg.AvailabilityCheckEnabled = false
	cfg.TargetPort = port
	cfg.MaxLatency = config.Duration(time.Second)
	cfg.DialTimeout = config.Duration(time.Second)
	s := New(cfg, slog.New(slog.NewTextHandler(io.Discard, nil)))
	got, err := s.Probe(context.Background(), netip.MustParseAddr("127.0.0.1"))
	if err != nil {
		t.Fatal(err)
	}
	if got.IP.String() != "127.0.0.1" {
		t.Fatalf("ip = %s", got.IP)
	}
}

func TestTCPProbeAvailabilityCheckIsIndependent(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	var status atomic.Int64
	status.Store(http.StatusServiceUnavailable)
	server := &http.Server{Handler: http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		if status.Load() == http.StatusOK {
			time.Sleep(120 * time.Millisecond)
		}
		w.WriteHeader(int(status.Load()))
	})}
	defer server.Close()
	go server.Serve(listener)

	_, portText, _ := net.SplitHostPort(listener.Addr().String())
	port, _ := strconv.Atoi(portText)
	cfg := config.Defaults()
	cfg.TargetPort = port
	cfg.TLS = false
	cfg.CheckURL = "http://example.com/availability"
	cfg.MaxLatency = config.Duration(50 * time.Millisecond)
	cfg.DialTimeout = config.Duration(time.Second)
	ip := netip.MustParseAddr("127.0.0.1")

	cfg.AvailabilityCheckEnabled = false
	if _, err := New(cfg, slog.New(slog.NewTextHandler(io.Discard, nil))).ProbeWithMode(context.Background(), ip, "tcp"); err != nil {
		t.Fatalf("disabled availability check rejected TCP probe: %v", err)
	}

	cfg.AvailabilityCheckEnabled = true
	_, err = New(cfg, slog.New(slog.NewTextHandler(io.Discard, nil))).ProbeWithMode(context.Background(), ip, "tcp")
	var pe *ProbeError
	if !errors.As(err, &pe) || pe.Kind != "availability_status" {
		t.Fatalf("expected availability_status, got %v", err)
	}

	status.Store(http.StatusOK)
	if _, err := New(cfg, slog.New(slog.NewTextHandler(io.Discard, nil))).ProbeWithMode(context.Background(), ip, "tcp"); err != nil {
		t.Fatalf("availability response time should not replace TCP latency limit: %v", err)
	}
}

func TestParsePingLatency(t *testing.T) {
	got, ok := parsePingLatency("64 bytes from 127.0.0.1: icmp_seq=1 ttl=64 time=12.345 ms")
	if !ok {
		t.Fatal("expected ping latency")
	}
	if got != 12345*time.Microsecond {
		t.Fatalf("latency = %s", got)
	}
}

func TestDownloadSpeed(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	payload := make([]byte, 512*1024)
	server := &http.Server{Handler: http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write(payload)
	})}
	defer server.Close()
	go server.Serve(listener)

	cfg := config.Defaults()
	cfg.SpeedTest.Enabled = true
	cfg.SpeedTest.URL = "http://" + listener.Addr().String() + "/download"
	cfg.SpeedTest.MinMBps = 0.01
	cfg.SpeedTest.Timeout = config.Duration(2 * time.Second)
	cfg.SpeedTest.MaxCandidates = 1
	s := New(cfg, slog.New(slog.NewTextHandler(io.Discard, nil)))
	speed, err := s.DownloadSpeed(context.Background(), netip.MustParseAddr("127.0.0.1"), cfg.SpeedTest.Timeout.Value())
	if err != nil {
		t.Fatal(err)
	}
	if speed <= 0 {
		t.Fatalf("speed = %f", speed)
	}
}
