#!/bin/sh
if [ -z "${BASH_VERSION:-}" ]; then
  if [ -f /etc/openwrt_release ] && ! command -v bash >/dev/null 2>&1; then
    opkg update
    opkg install bash
  fi
  exec bash "$0" "$@"
fi
set -Eeuo pipefail

PROJECT_NAME="cfnat-linux"
GO_VERSION="1.26.4"
INSTALL_BIN="/usr/local/bin/cfnat"
CONFIG_DIR="/etc/cfnat"
STATE_DIR="/var/lib/cfnat"
SERVICE_FILE="/etc/systemd/system/cfnat.service"
OPENWRT_SERVICE_FILE="/etc/init.d/cfnat"
WEB_RESTART_SERVICE_FILE="/etc/systemd/system/cfnat-web-restart.service"
WEB_RESTART_PATH_FILE="/etc/systemd/system/cfnat-web-restart.path"
UPDATE_SERVICE_FILE="/etc/systemd/system/cfnat-update.service"
UPDATE_TIMER_FILE="/etc/systemd/system/cfnat-update.timer"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd -- "${SCRIPT_DIR}/.." && pwd)"

die() { echo "错误: $*" >&2; exit 1; }
info() { echo "==> $*"; }
retry() { echo "输入无效: $*，请重新输入。" >&2; }

sha256_check_file() {
  local sums_file="$1"
  if sha256sum --check --status "${sums_file}" >/dev/null 2>&1; then
    return 0
  fi
  sha256sum -c -s "${sums_file}" >/dev/null 2>&1
}

sha256_check_stdin() {
  local data
  data="$(cat)"
  if printf '%s\n' "${data}" | sha256sum --check --status >/dev/null 2>&1; then
    return 0
  fi
  printf '%s\n' "${data}" | sha256sum -c -s >/dev/null 2>&1
}

prompt_listen() {
  local value port_number
  while true; do
    read -r -p "本地监听地址 [0.0.0.0:1234]: " value
    value="${value:-0.0.0.0:1234}"
    if [[ "${value}" =~ ^(\[[0-9A-Fa-f:.%]+\]|[A-Za-z0-9._-]+):([0-9]{1,5})$ ]]; then
      port_number=$((10#${BASH_REMATCH[2]}))
      if (( port_number >= 1 && port_number <= 65535 )); then
        LISTEN="${value}"
        return
      fi
    fi
    retry "监听地址应类似 0.0.0.0:1234 或 [::]:1234，端口范围为 1-65535"
  done
}

prompt_ip_version() {
  local value
  while true; do
    read -r -p "IP 版本 [4]: " value
    value="${value:-4}"
    if [[ "${value}" == "4" || "${value}" == "6" ]]; then
      IP_VERSION="${value}"
      return
    fi
    retry "IP 版本只能是 4 或 6"
  done
}

prompt_max_latency() {
  local value
  while true; do
    read -r -p "最大优选延迟，单位毫秒 [800]: " value
    value="${value:-800}"
    if [[ "${value}" =~ ^[1-9][0-9]*$ ]] && (( value <= 60000 )); then
      MAX_LATENCY="${value}ms"
      return
    fi
    retry "最大延迟必须是 1-60000 的整数（毫秒）"
  done
}

prompt_min_healthy_count() {
  local value
  while true; do
    read -r -p "健康 IP 少于多少个时整池重选 [5]: " value
    value="${value:-5}"
    if [[ "${value}" =~ ^[1-9][0-9]*$ ]] && (( value <= 10 )); then
      MIN_HEALTHY_COUNT="${value}"
      return
    fi
    retry "最小健康 IP 数必须是 1-10 的整数，且不能大于默认池大小 10"
  done
}

prompt_latency_monitor_interval() {
  local value
  while true; do
    read -r -p "延迟监控间隔，单位秒 [2]: " value
    value="${value:-2}"
    if [[ "${value}" =~ ^[1-9][0-9]*$ ]] && (( value <= 3600 )); then
      LATENCY_MONITOR_INTERVAL="${value}s"
      return
    fi
    retry "延迟监控间隔必须是 1-3600 的整数（秒）"
  done
}

prompt_web_settings() {
  local value port first second
  WEB_BOOL=true
  WEB_LISTEN="0.0.0.0:8787"
  WEB_USERNAME="admin"
  WEB_PASSWORD_SHA256="8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918"
  info "Web 管理面板默认启用，并会独立于 cfnat 扫描与 Shodan 任务保持后台运行。"
  while true; do
    read -r -p "Web 管理面板监听地址 [0.0.0.0:8787]: " value
    value="${value:-0.0.0.0:8787}"
    if [[ "${value}" =~ ^(\[[0-9A-Fa-f:.%]+\]|[A-Za-z0-9._-]+):([0-9]{1,5})$ ]]; then
      port=$((10#${BASH_REMATCH[2]}))
      if (( port >= 1 && port <= 65535 )); then
        WEB_LISTEN="${value}"
        break
      fi
    fi
    retry "Web 监听地址应类似 0.0.0.0:8787 或 [::]:8787"
  done
  while true; do
    read -r -p "Web 用户名 [admin]: " value
    WEB_USERNAME="${value:-admin}"
    [[ -n "${WEB_USERNAME}" && "${WEB_USERNAME}" != *[[:space:]]* ]] && break
    retry "Web 用户名不能为空且不能包含空白字符"
  done
  while true; do
    read -r -s -p "Web 密码: " first
    echo
    if [[ ${#first} -lt 6 ]]; then
      retry "Web 密码至少 6 位"
      continue
    fi
    read -r -s -p "再次输入 Web 密码: " second
    echo
    if [[ "${first}" != "${second}" ]]; then
      retry "两次密码不一致"
      continue
    fi
    WEB_PASSWORD_SHA256="$(printf '%s' "${first}" | sha256sum | awk '{print $1}')"
    break
  done
}

prompt_shodan_settings() {
  local value
  while true; do
    read -r -p "启用 Shodan IP Panel？[y/N]: " value
    case "${value}" in
      y|Y|yes|YES|Yes) SHODAN_BOOL=true; return ;;
      ""|n|N|no|NO|No) SHODAN_BOOL=false; return ;;
      *) retry "请输入 y 或 n" ;;
    esac
  done
}

prompt_speed_test_settings() {
  local value
  while true; do
    read -r -p "启用下载测速筛选？[y/N]: " value
    case "${value}" in
      y|Y|yes|YES|Yes) SPEED_TEST_BOOL=true; break ;;
      ""|n|N|no|NO|No) SPEED_TEST_BOOL=false; break ;;
      *) retry "请输入 y 或 n" ;;
    esac
  done
  while [[ "${SPEED_TEST_BOOL}" == true ]]; do
    read -r -p "最低下载速度，单位 MB/s [5]: " value
    value="${value:-5}"
    if [[ "${value}" =~ ^[0-9]+([.][0-9]+)?$ ]] && awk "BEGIN {exit !(${value} > 0 && ${value} <= 100000)}"; then
      SPEED_TEST_MIN_MBPS="${value}"
      break
    fi
    retry "最低下载速度必须是大于 0 的数字"
  done
  while [[ "${SPEED_TEST_BOOL}" == true ]]; do
    read -r -p "单个 IP 测速时间，单位秒 [10]: " value
    value="${value:-10}"
    if [[ "${value}" =~ ^[1-9][0-9]*$ ]] && (( value <= 120 )); then
      SPEED_TEST_TIMEOUT="${value}s"
      break
    fi
    retry "测速时间必须是 1-120 的整数（秒）"
  done
  while [[ "${SPEED_TEST_BOOL}" == true ]]; do
    read -r -p "TCP 初筛后最多测速多少个候选 IP [50]: " value
    value="${value:-50}"
    if [[ "${value}" =~ ^[1-9][0-9]*$ ]] && (( value <= 1000 )); then
      SPEED_TEST_MAX_CANDIDATES="${value}"
      break
    fi
    retry "最多测速候选数必须是 1-1000 的整数"
  done
  while [[ "${SPEED_TEST_BOOL}" == true ]]; do
    read -r -p "下载测速并发数 [3]: " value
    value="${value:-3}"
    if [[ "${value}" =~ ^[1-9][0-9]*$ ]] && (( value <= 50 )); then
      SPEED_TEST_CONCURRENCY="${value}"
      break
    fi
    retry "下载测速并发数必须是 1-50 的整数"
  done
}

prompt_colos() {
  local value item invalid
  local -a items
  while true; do
    read -r -p "限定数据中心，逗号分隔（留空不限制）: " value
    COLO_JSON=""
    invalid=""
    IFS=',' read -r -a items <<< "${value}"
    for item in "${items[@]}"; do
      item="${item//[[:space:]]/}"
      [[ -z "${item}" ]] && continue
      if [[ ! "${item}" =~ ^[A-Za-z]{3}$ ]]; then
        invalid="${item}"
        break
      fi
      item="$(printf '%s' "${item}" | tr '[:lower:]' '[:upper:]')"
      [[ -n "${COLO_JSON}" ]] && COLO_JSON+=","
      COLO_JSON+="\"${item}\""
    done
    if [[ -z "${invalid}" ]]; then
      return
    fi
    retry "数据中心代码 ${invalid} 格式错误，应为三个英文字母，例如 HKG,SJC"
  done
}

prompt_dns_enabled() {
  local value
  while true; do
    read -r -p "启用 Cloudflare DNS 同步？[y/N]: " value
    case "${value}" in
      y|Y|yes|YES|Yes) DNS_BOOL=true; return ;;
      ""|n|N|no|NO|No) DNS_BOOL=false; return ;;
      *) retry "请输入 y 或 n" ;;
    esac
  done
}

valid_record_name() {
  local name="$1" label
  local -a labels
  [[ "${name}" == *.* && "${name}" != .* && "${name}" != *. && "${name}" != *..* ]] || return 1
  IFS='.' read -r -a labels <<< "${name}"
  for label in "${labels[@]}"; do
    [[ "${label}" =~ ^[A-Za-z0-9]$ || "${label}" =~ ^[A-Za-z0-9][A-Za-z0-9-]{0,61}[A-Za-z0-9]$ ]] || return 1
  done
}

prompt_dns_settings() {
  while true; do
    read -r -p "Cloudflare Zone ID: " ZONE_ID
    [[ "${ZONE_ID}" =~ ^[A-Fa-f0-9]{32}$ ]] && break
    retry "Zone ID 应为 Cloudflare 提供的 32 位十六进制字符串"
  done
  while true; do
    read -r -p "完整记录名（例如 best.example.com）: " RECORD_NAME
    valid_record_name "${RECORD_NAME}" && break
    retry "请输入完整且合法的域名，例如 best.example.com"
  done
  while true; do
    read -r -p "同步前几个优选 IP [1，最大 10]: " SYNC_COUNT
    SYNC_COUNT="${SYNC_COUNT:-1}"
    if [[ "${SYNC_COUNT}" =~ ^[1-9][0-9]*$ ]] && (( SYNC_COUNT <= 10 )); then
      break
    fi
    retry "同步数量必须是 1-10 的整数"
  done
  while true; do
    read -r -s -p "Cloudflare API Token: " TOKEN
    echo
    if [[ -n "${TOKEN}" && "${TOKEN}" != *[[:space:]]* ]]; then
      break
    fi
    retry "API Token 不能为空且不能包含空白字符"
  done
  while true; do
    read -r -p "DNS 是否按延迟排序冷却同步？[y/N]: " value
    case "${value}" in
      y|Y|yes|YES|Yes) DNS_LATENCY_SYNC_BOOL=true; break ;;
      ""|n|N|no|NO|No) DNS_LATENCY_SYNC_BOOL=false; break ;;
      *) retry "请输入 y 或 n" ;;
    esac
  done
  while [[ "${DNS_LATENCY_SYNC_BOOL}" == true ]]; do
    read -r -p "DNS 延迟排序同步冷却时间，单位分钟 [5]: " value
    value="${value:-5}"
    if [[ "${value}" =~ ^[1-9][0-9]*$ ]] && (( value <= 10080 )); then
      DNS_LATENCY_SYNC_INTERVAL="${value}m"
      break
    fi
    retry "冷却时间必须是 1-10080 的整数（分钟）"
  done
}

[[ "${EUID}" -eq 0 ]] || die "请使用 root 运行：sudo ./scripts/install.sh"
if [[ -f /etc/openwrt_release ]]; then
  INIT_SYSTEM="openwrt"
  info "检测到 OpenWrt，使用 procd 服务管理"
  opkg update
  for pkg in bash ca-bundle ca-certificates curl tar coreutils-sha256sum coreutils-install coreutils-nohup grep sed gawk; do
    opkg list-installed "$pkg" >/dev/null 2>&1 || opkg install "$pkg" || true
  done
  command -v install >/dev/null 2>&1 || opkg install coreutils-install
  command -v sha256sum >/dev/null 2>&1 || opkg install coreutils-sha256sum
elif command -v systemctl >/dev/null 2>&1; then
  INIT_SYSTEM="systemd"
else
  die "当前系统暂只支持 systemd 或 OpenWrt procd"
fi
[[ -f "${PROJECT_DIR}/go.mod" ]] || die "请在完整项目目录中运行安装脚本"

case "$(uname -m)" in
  x86_64) GO_ARCH="amd64"; GO_SHA="1153d3d50e0ac764b447adfe05c2bcf08e889d42a02e0fe0259bd47f6733ad7f" ;;
  aarch64|arm64) GO_ARCH="arm64"; GO_SHA="ef758ae7c6cf9267c9c0ef080b8965f453d89ab2d25d9eb22de4405925238768" ;;
  i386|i686) GO_ARCH="386"; GO_SHA="5ca0982791791559d11a0eba939617a94c3f37c21aa514a55c415b9167efc658" ;;
  *) die "不支持的 CPU 架构: $(uname -m)" ;;
esac

TMP_DIR="$(mktemp -d)"
cleanup() { rm -rf "${TMP_DIR}"; }
trap cleanup EXIT

install -d -o root -g root -m 0755 /usr/local/bin

BUNDLED_BIN="${PROJECT_DIR}/dist/cfnat-linux-${GO_ARCH}"
if [[ -f "${BUNDLED_BIN}" && -f "${PROJECT_DIR}/dist/SHA256SUMS" ]]; then
  command -v sha256sum >/dev/null 2>&1 || die "缺少 sha256sum，无法校验内置二进制"
  (cd "${PROJECT_DIR}/dist" && sha256_check_file SHA256SUMS) || die "内置二进制校验失败"
  info "安装已校验的 Linux ${GO_ARCH} 二进制"
  install -m 0755 "${BUNDLED_BIN}" "${INSTALL_BIN}"
else
  BUILD_GO="$(command -v go || true)"
  if [[ -z "${BUILD_GO}" ]]; then
    command -v curl >/dev/null 2>&1 || die "缺少 curl"
    command -v sha256sum >/dev/null 2>&1 || die "缺少 sha256sum"
    GO_FILE="go${GO_VERSION}.linux-${GO_ARCH}.tar.gz"
    info "下载临时 Go ${GO_VERSION} 工具链"
    curl --fail --location --retry 3 "https://go.dev/dl/${GO_FILE}" -o "${TMP_DIR}/${GO_FILE}"
    echo "${GO_SHA}  ${TMP_DIR}/${GO_FILE}" | sha256_check_stdin || die "Go 工具链校验失败"
    mkdir -p "${TMP_DIR}/toolchain"
    tar -xzf "${TMP_DIR}/${GO_FILE}" -C "${TMP_DIR}/toolchain"
    BUILD_GO="${TMP_DIR}/toolchain/go/bin/go"
  fi
  info "编译 ${PROJECT_NAME}"
  (cd "${PROJECT_DIR}" && CGO_ENABLED=0 "${BUILD_GO}" build -trimpath -ldflags="-s -w -X main.version=local" -o "${TMP_DIR}/cfnat" ./cmd/cfnat)
  install -m 0755 "${TMP_DIR}/cfnat" "${INSTALL_BIN}"
fi

if [[ "${INIT_SYSTEM}" == "openwrt" ]]; then
  RUN_USER="root"
  RUN_GROUP="root"
else
  RUN_USER="cfnat"
  RUN_GROUP="cfnat"
  if ! getent passwd cfnat >/dev/null; then
    useradd --system --home-dir "${STATE_DIR}" --shell /usr/sbin/nologin cfnat
  fi
fi
install -d -o root -g "${RUN_GROUP}" -m 0750 "${CONFIG_DIR}"
install -d -o "${RUN_USER}" -g "${RUN_GROUP}" -m 0750 "${STATE_DIR}"

if [[ ! -f "${CONFIG_DIR}/config.json" ]]; then
  info "生成配置文件"
  prompt_listen
  prompt_ip_version
  prompt_max_latency
  prompt_min_healthy_count
  prompt_latency_monitor_interval
  WEB_BOOL=true; WEB_LISTEN="0.0.0.0:8787"; WEB_USERNAME="admin"; WEB_PASSWORD_SHA256="8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918"; SHODAN_BOOL=false
  prompt_web_settings
  prompt_shodan_settings
  SPEED_TEST_BOOL=false; SPEED_TEST_MIN_MBPS=5; SPEED_TEST_TIMEOUT="10s"; SPEED_TEST_MAX_CANDIDATES=50; SPEED_TEST_CONCURRENCY=3
  prompt_speed_test_settings
  if [[ "${IP_VERSION}" == "4" ]]; then SOURCE="https://www.cloudflare.com/ips-v4"; else SOURCE="https://www.cloudflare.com/ips-v6"; fi
  prompt_colos
  DNS_BOOL=false; ZONE_ID=""; RECORD_NAME=""; SYNC_COUNT=1; TOKEN=""; DNS_LATENCY_SYNC_BOOL=false; DNS_LATENCY_SYNC_INTERVAL="5m"
  prompt_dns_enabled
  if [[ "${DNS_BOOL}" == true ]]; then
    prompt_dns_settings
  fi
  if [[ "${IP_VERSION}" == "4" ]]; then RECORD_TYPE="A"; else RECORD_TYPE="AAAA"; fi
  cat > "${CONFIG_DIR}/config.json" <<EOF
{
  "config_version": 23,
  "listen": "${LISTEN}",
  "ip_version": ${IP_VERSION},
  "ip_sources": ["${SOURCE}"],
  "ip_blacklist": [],
  "random_ips": true,
  "max_candidates": 2000,
  "valid_ip_count": 20,
  "pool_size": 10,
  "min_healthy_count": ${MIN_HEALTHY_COUNT},
  "concurrency": 100,
  "scan_probe_concurrency": 20,
  "health_concurrency": 20,
  "recovery_concurrency": 10,
  "target_port": 443,
  "tls": true,
  "tls_server_name": "",
  "insecure_skip_verify": false,
  "check_url": "https://cloudflare.com/cdn-cgi/trace",
  "expected_status": 200,
  "probe_mode": "http",
  "scan_probe_mode": "http",
  "health_probe_mode": "http",
  "recovery_probe_mode": "http",
  "max_latency": "${MAX_LATENCY}",
  "dial_timeout": "3s",
  "colos": [${COLO_JSON}],
  "scan_interval_enabled": true,
  "scan_interval": "6h",
  "latency_monitor_interval": "${LATENCY_MONITOR_INTERVAL}",
  "health_interval": "60s",
  "health_failures": 3,
  "recovery_cooldown": "5m",
  "recovery_successes": 2,
  "state_file": "/var/lib/cfnat/state.json",
  "source_cache_dir": "/var/lib/cfnat/ip-cache",
  "log_level": "info",
  "speed_test": {
    "enabled": ${SPEED_TEST_BOOL},
    "url": "https://speed.cloudflare.com/__down?bytes=50000000",
    "min_mbps": ${SPEED_TEST_MIN_MBPS},
    "timeout": "${SPEED_TEST_TIMEOUT}",
    "max_candidates": ${SPEED_TEST_MAX_CANDIDATES},
    "concurrency": ${SPEED_TEST_CONCURRENCY}
  },
  "post_pool_speed_test": {
    "enabled": false,
    "min_mbps": 1,
    "timeout": "5s",
    "auto_blacklist": false,
    "exempt_list": [],
    "force_test_list": [],
    "exempt_direct_pool_enabled": true,
    "exempt_latency_filter_enabled": true,
    "exempt_max_latency": "${MAX_LATENCY}",
    "exempt_probe_mode": "tcp",
    "exempt_latency_concurrency": 20,
    "exempt_recovery_evict_enabled": true,
    "exempt_recovery_window": "24h",
    "exempt_recovery_max_ratio": 0.6,
    "exempt_recovery_min_samples": 20
  },
  "blacklist_speed_test": {
    "enabled": false,
    "interval": "24h",
    "timeout": "5s",
    "concurrency": 3
  },
  "management": {
    "password_enabled": false,
    "password_sha256": ""
  },
  "update": {
    "check_enabled": true,
    "check_interval": "6h",
    "auto_update_enabled": false,
    "repository": "Jk-z-Box/cfnat-linux"
  },
  "web": {
    "enabled": ${WEB_BOOL},
    "listen": "${WEB_LISTEN}",
    "username": "${WEB_USERNAME}",
    "password_sha256": "${WEB_PASSWORD_SHA256}"
  },
  "shodan": {
    "enabled": ${SHODAN_BOOL},
    "data_dir": "/var/lib/cfnat/shodan"
  },
  "cloudflare_dns": {
    "enabled": ${DNS_BOOL},
    "zone_id": "${ZONE_ID}",
    "record_name": "${RECORD_NAME}",
    "record_type": "${RECORD_TYPE}",
    "sync_count": ${SYNC_COUNT},
    "ttl": 1,
    "proxied": false,
    "token_env": "CF_API_TOKEN",
    "marker": "managed-by:cfnat-linux",
    "latency_sync_enabled": ${DNS_LATENCY_SYNC_BOOL},
    "latency_sync_interval": "${DNS_LATENCY_SYNC_INTERVAL}"
  }
}
EOF
  printf 'CF_API_TOKEN=%q\n' "${TOKEN}" > "${CONFIG_DIR}/cfnat.env"
  chown root:"${RUN_GROUP}" "${CONFIG_DIR}/config.json" "${CONFIG_DIR}/cfnat.env"
  chmod 0660 "${CONFIG_DIR}/config.json"
  chmod 0640 "${CONFIG_DIR}/cfnat.env"
else
  info "保留已有配置 ${CONFIG_DIR}/config.json"
  cp -p "${CONFIG_DIR}/config.json" "${CONFIG_DIR}/config.json.bak"
  "${INSTALL_BIN}" -config "${CONFIG_DIR}/config.json" migrate-config
  chown root:"${RUN_GROUP}" "${CONFIG_DIR}/config.json"
  chmod 0660 "${CONFIG_DIR}/config.json"
  [[ -f "${CONFIG_DIR}/cfnat.env" ]] || { touch "${CONFIG_DIR}/cfnat.env"; chown root:"${RUN_GROUP}" "${CONFIG_DIR}/cfnat.env"; chmod 0640 "${CONFIG_DIR}/cfnat.env"; }
fi

if [[ "${INIT_SYSTEM}" == "openwrt" ]]; then
  install -d -o root -g root -m 0755 /usr/local/lib/cfnat
  cat > /usr/local/lib/cfnat/run-openwrt.sh <<'EOF'
#!/bin/sh
set -a
[ -f /etc/cfnat/cfnat.env ] && . /etc/cfnat/cfnat.env
exec /usr/local/bin/cfnat -config /etc/cfnat/config.json run
EOF
  chmod 0755 /usr/local/lib/cfnat/run-openwrt.sh
  cat > /usr/local/lib/cfnat/restart-watch-openwrt.sh <<'EOF'
#!/bin/sh
while :; do
  if [ -e /var/lib/cfnat/restart-request ]; then
    rm -f /var/lib/cfnat/restart-request
    /etc/init.d/cfnat restart >/dev/null 2>&1 || true
    exit 0
  fi
  sleep 2
done
EOF
  chmod 0755 /usr/local/lib/cfnat/restart-watch-openwrt.sh
  cat > "${OPENWRT_SERVICE_FILE}" <<'EOF'
#!/bin/sh /etc/rc.common
START=99
STOP=10
USE_PROCD=1

start_service() {
  procd_open_instance main
  procd_set_param command /usr/local/lib/cfnat/run-openwrt.sh
  procd_set_param respawn 10 5 5
  procd_set_param stdout 1
  procd_set_param stderr 1
  procd_close_instance

  procd_open_instance restart_watch
  procd_set_param command /usr/local/lib/cfnat/restart-watch-openwrt.sh
  procd_set_param respawn 5 3 5
  procd_set_param stdout 1
  procd_set_param stderr 1
  procd_close_instance
}
EOF
  chmod 0755 "${OPENWRT_SERVICE_FILE}"
else
cat > "${SERVICE_FILE}" <<'EOF'
[Unit]
Description=Cloudflare IP optimizer, TCP forwarder and DNS synchronizer
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=cfnat
Group=cfnat
SupplementaryGroups=systemd-journal
EnvironmentFile=-/etc/cfnat/cfnat.env
ExecStart=/usr/local/bin/cfnat -config /etc/cfnat/config.json run
Restart=on-failure
RestartSec=10s
TimeoutStopSec=30s
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
LockPersonality=true
MemoryDenyWriteExecute=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
ReadWritePaths=/var/lib/cfnat /etc/cfnat
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
EOF

cat > "${WEB_RESTART_SERVICE_FILE}" <<'EOF'
[Unit]
Description=Restart cfnat requested by Web panel

[Service]
Type=oneshot
ExecStart=/bin/sh -c 'rm -f /var/lib/cfnat/restart-request; /bin/systemctl restart cfnat.service'
EOF

cat > "${WEB_RESTART_PATH_FILE}" <<'EOF'
[Unit]
Description=Watch cfnat Web restart request

[Path]
PathExists=/var/lib/cfnat/restart-request
Unit=cfnat-web-restart.service

[Install]
WantedBy=multi-user.target
EOF

cat > "${UPDATE_SERVICE_FILE}" <<'EOF'
[Unit]
Description=cfnat-linux background updater
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/cfnatctl update --auto
EOF

cat > "${UPDATE_TIMER_FILE}" <<'EOF'
[Unit]
Description=Run cfnat-linux background updater periodically

[Timer]
OnBootSec=10m
OnUnitActiveSec=1h
AccuracySec=5m
Persistent=true

[Install]
WantedBy=timers.target
EOF
fi

install -d -o root -g root -m 0755 /usr/local/lib/cfnat
install -m 0755 "${PROJECT_DIR}/scripts/cfnatctl.sh" /usr/local/bin/cfnatctl
install -m 0755 "${PROJECT_DIR}/scripts/uninstall.sh" /usr/local/lib/cfnat/uninstall.sh
if [[ "${INIT_SYSTEM}" == "openwrt" ]]; then
  ln -sf /usr/local/bin/cfnat /usr/bin/cfnat
  ln -sf /usr/local/bin/cfnatctl /usr/bin/cfnatctl
fi

"${INSTALL_BIN}" -config "${CONFIG_DIR}/config.json" check-config
if [[ "${INIT_SYSTEM}" == "openwrt" ]]; then
  "${OPENWRT_SERVICE_FILE}" enable
  "${OPENWRT_SERVICE_FILE}" restart
  if command -v crontab >/dev/null 2>&1; then
    tmp_cron="$(mktemp)"
    crontab -l 2>/dev/null | grep -v '/usr/local/bin/cfnatctl update --auto' > "${tmp_cron}" || true
    echo '17 * * * * /usr/local/bin/cfnatctl update --auto >/tmp/cfnat-update.log 2>&1' >> "${tmp_cron}"
    crontab "${tmp_cron}" || true
    rm -f "${tmp_cron}"
    /etc/init.d/cron enable >/dev/null 2>&1 || true
    /etc/init.d/cron restart >/dev/null 2>&1 || true
  fi
else
  systemctl daemon-reload
  systemctl enable cfnat
  systemctl enable --now cfnat-web-restart.path
  systemctl enable --now cfnat-update.timer
  systemctl restart cfnat
fi
info "安装完成"
echo "状态: cfnatctl status"
echo "日志: cfnatctl logs"
if [[ "${INIT_SYSTEM}" == "openwrt" ]]; then
  echo "管理面板: cfnatctl"
else
  echo "管理面板: sudo cfnatctl"
fi
